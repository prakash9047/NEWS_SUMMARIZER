from django.contrib import admin
from django.urls import path, include
from news_app.views import home  # import the home view
# backend/config/urls.py

from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('news_app.urls')),
    path('', home, name='home'), 
    # includes all app-level routes
]
