import requests

def translate_text(text, target_lang='en'):
    url = "https://libretranslate.de/translate"
    payload = {
        "q": text,
        "source": "auto",
        "target": target_lang,
        "format": "text"
    }
    headers = {
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        if response.status_code == 200:
            return response.json().get("translatedText", "")
        return "Translation error"
    except Exception as e:
        return f"Error: {str(e)}"
