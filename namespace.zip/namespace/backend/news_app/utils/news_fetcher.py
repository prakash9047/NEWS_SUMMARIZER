import os
import requests
from django.utils import timezone
from dateutil import parser
from news_app.models import NewsArticle

NEWS_API_KEY = os.environ.get('NEWS_API_KEY', 'YOUR_NEWS_API_KEY')
CATEGORIES = ['general', 'business', 'entertainment', 'health', 'science', 'sports', 'technology']

def fetch_category_news(category):
    """
    Fetch news articles for a given category (sports, technology, etc.).
    """
    if category not in CATEGORIES:
        print(f"Invalid category: {category}")
        return []

    url = f"https://newsapi.org/v2/top-headlines?country=us&category={category}&apiKey={NEWS_API_KEY}"
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        articles = data.get('articles', [])
        for article in articles:
            title = article.get('title') or "No Title"
            description = article.get('description')
            content = article.get('content')
            author = article.get('author')
            article_url = article.get('url')
            image_url = article.get('urlToImage')
            published_at = article.get('publishedAt')
            source_name = article.get('source', {}).get('name')

            published_datetime = parser.parse(published_at) if published_at else timezone.now()

            # Insert or update the article in the database
            NewsArticle.objects.get_or_create(
                url=article_url,
                defaults={
                    'title': title,
                    'description': description,
                    'content': content,
                    'author': author,
                    'urlToImage': image_url,
                    'publishedAt': published_datetime,
                    'source_name': source_name,
                    'category': category,
                }
            )
        return articles
    else:
        print(f"Error fetching {category}: {response.status_code}, {response.text}")
        return []

def fetch_sports_news():
    return fetch_category_news('sports')

def fetch_technology_news():
    return fetch_category_news('technology')

def fetch_latest_news():
    # Fetch all categories, but call fetch_sports_news() and fetch_technology_news separately
    all_articles = []
    
    # Fetch Sports and Technology news first
    all_articles.extend(fetch_sports_news())
    all_articles.extend(fetch_technology_news())

    # You can also fetch other categories if needed
    for category in CATEGORIES:
        if category not in ['sports', 'technology']:  # Avoid fetching these categories again
            all_articles.extend(fetch_category_news(category))

    return all_articles
