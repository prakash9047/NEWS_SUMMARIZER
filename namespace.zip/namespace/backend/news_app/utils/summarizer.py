import nltk
from nltk.tokenize import sent_tokenize

nltk.download('punkt')

def summarize_text(text, max_sentences=3):
    """
    A naive summarizer that takes the first few sentences.
    Replace with advanced algorithms if you wish.
    """
    sentences = sent_tokenize(text)
    summary = ' '.join(sentences[:max_sentences])
    return summary
