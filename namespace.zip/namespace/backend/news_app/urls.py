# backend/news_app/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('api/news/', views.NewsListView.as_view(), name='news-list'),
    path('api/news/<int:pk>/', views.NewsDetailView.as_view(), name='news-detail'),
    path('api/news/<int:pk>/summarize/', views.SummarizeView.as_view(), name='summarize-article'),
    path('api/news/<int:pk>/translate/', views.TranslateView.as_view(), name='translate-article'),
    path('api/news/recommended/', views.RecommendedNewsView.as_view(), name='recommended-news'),
    
    # Category-based clean URLs like /api/news/sports/
    path('api/news/category/<str:category>/', views.NewsByCategoryAPIView.as_view(), name='news-by-category'),
    path('api/news/sports/', views.SportsNewsView.as_view(), name='sports-news'),
    path('api/news/technology/', views.TechnologyNewsView.as_view(), name='technology-news'),
]
