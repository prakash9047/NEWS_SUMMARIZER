from news_app.models import NewsArticle

def get_recommended_articles(user_id=None, search_term=None):
    """
    Return recommended news articles based on user_id or search term.
    This is a naive example:
    - If search_term is provided, filter on that.
    - Otherwise, return latest news or any logic you prefer.
    """
    queryset = NewsArticle.objects.all().order_by('-publishedAt')
    if search_term:
        queryset = queryset.filter(title__icontains=search_term)
    return queryset
