# backend/news_app/views.py

from django.http import HttpResponse
from django.shortcuts import render
from rest_framework import generics, status
from rest_framework.response import Response

from .models import NewsArticle
from .serializers import NewsArticleSerializer
from .utils.summarizer import summarize_text
from .utils.translator import translate_text
from .services.recommendation import get_recommended_articles


class NewsListView(generics.ListAPIView):
    serializer_class = NewsArticleSerializer

    def get_queryset(self):
        queryset = NewsArticle.objects.all().order_by('-publishedAt')
        category = self.request.query_params.get('category')
        if category:
            queryset = queryset.filter(category=category)
        return queryset


class NewsDetailView(generics.RetrieveAPIView):
    queryset = NewsArticle.objects.all()
    serializer_class = NewsArticleSerializer


class SummarizeView(generics.GenericAPIView):
    serializer_class = NewsArticleSerializer

    def get(self, request, pk):
        try:
            article = NewsArticle.objects.get(pk=pk)
            summarized = summarize_text(article.content or "")
            return Response({"original": article.content, "summary": summarized})
        except NewsArticle.DoesNotExist:
            return Response({"error": "Article not found"}, status=status.HTTP_404_NOT_FOUND)


class TranslateView(generics.GenericAPIView):
    serializer_class = NewsArticleSerializer

    def get(self, request, pk):
        lang = request.query_params.get('lang', 'en')
        try:
            article = NewsArticle.objects.get(pk=pk)
            translated = translate_text(article.content or "", target_lang=lang)
            return Response({
                "original": article.content,
                "translated": translated,
                "language": lang
            })
        except NewsArticle.DoesNotExist:
            return Response({"error": "Article not found"}, status=status.HTTP_404_NOT_FOUND)


class RecommendedNewsView(generics.ListAPIView):
    serializer_class = NewsArticleSerializer

    def get_queryset(self):
        user_id = self.request.query_params.get('user_id')
        search_term = self.request.query_params.get('search')
        return get_recommended_articles(user_id=user_id, search_term=search_term)


class NewsByCategoryAPIView(generics.ListAPIView):
    """
    View that returns articles filtered by category using clean URLs like /api/news/sports/
    """
    serializer_class = NewsArticleSerializer

    def get_queryset(self):
        category = self.kwargs.get('category')
        return NewsArticle.objects.filter(category=category).order_by('-publishedAt')


def home(request):
    return HttpResponse("<h1>Welcome to My News Project</h1><p>This is the home page.</p>")
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from news_app.models import NewsArticle
from news_app.serializers import NewsArticleSerializer

class SportsNewsView(APIView):
    """
    Fetch and display sports news.
    """
    def get(self, request):
        sports_articles = NewsArticle.objects.filter(category="sports").order_by('-publishedAt')
        serializer = NewsArticleSerializer(sports_articles, many=True)
        return Response(serializer.data)

class TechnologyNewsView(APIView):
    """
    Fetch and display technology news.
    """
    def get(self, request):
        tech_articles = NewsArticle.objects.filter(category="technology").order_by('-publishedAt')
        serializer = NewsArticleSerializer(tech_articles, many=True)
        return Response(serializer.data)
