from django.db import models

# Create your models here.
# backend/news_app/models.py
from django.db import models

class NewsArticle(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    content = models.TextField(null=True, blank=True)
    author = models.CharField(max_length=100, null=True, blank=True)
    url = models.CharField(max_length=500)  # Remove unique=True

    urlToImage = models.URLField(null=True, blank=True)
    publishedAt = models.DateTimeField()
    source_name = models.CharField(max_length=100, null=True, blank=True)
    category = models.CharField(max_length=50, null=True, blank=True)  # ✅ New field

    def __str__(self):
        return self.title
