import React from 'react'
import { Link } from 'react-router-dom'

function Header() {
  return (
    <header>
      <h2>My Live News Summarizer</h2>
      <nav>
        <Link to="/">Home</Link>
        <Link to="/category/sports">Sports</Link>
        <Link to="/category/technology">Technology</Link>
        <Link to="/login">Login</Link>
      </nav>
    </header>
  )
}

export default Header
