import React, { useEffect, useState } from 'react'
import axios from 'axios'
import NewsCard from '../components/NewsCard'
import SearchBar from '../components/SearchBar'

function HomePage() {
  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(true)

  const fetchData = async (search) => {
    setLoading(true)
    try {
      let endpoint = 'http://127.0.0.1:8000/api/news/'
      if (search) {
        // For a recommendation approach, you might do:
        endpoint = `http://127.0.0.1:8000/api/news/recommend/?search=${search}`
      }
      const res = await axios.get(endpoint)
      setArticles(res.data)
    } catch (error) {
      console.error(error)
    }
    setLoading(false)
  }

  useEffect(() => {
    fetchData()
  }, [])

  const handleSearch = (query) => {
    fetchData(query)
  }

  return (
    <div>
      <h1>Top News</h1>
      <SearchBar onSearch={handleSearch} />
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="news-grid">
          {articles.map((article) => (
            <NewsCard key={article.id} article={article} />
          ))}
        </div>
      )}
    </div>
  )
}

export default HomePage
